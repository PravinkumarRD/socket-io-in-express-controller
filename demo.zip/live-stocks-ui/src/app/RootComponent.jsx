import React, { Component } from "react";

import Taxi from "./components/stocks/container/Taxi";

export default class RootComponent extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <Taxi />
        );
    }
}