import * as io from "socket.io-client";
import { Observable } from "rxjs";

class TaxiService {
    constructor() {
        this._socketUrl = "http://localhost:9090";
        this._socket = io(this._socketUrl);
    }
    getTaxiApproval() {
        return new Observable(observer => {
            this._socket.on("taxiRequestApproval", result => {
                observer.next(result);
            });
        });
    }
    sendTaxiRequest() {
        return fetch("http://localhost:9090/api/taxi-request");
    }
}

export default new TaxiService();