import React, { Component } from 'react';

import taxiRequestService from "../services/taxi-service";

export default class Taxi extends Component {
    constructor(props) {
        super(props);
        this.state = {
            approvalStatus: "Not Approved Yet!"
        }
    }
    componentDidMount() {
        taxiRequestService.getTaxiApproval().subscribe(
            result => {
                this.setState({
                    approvalStatus: result
                });
            }
        );
        taxiRequestService.sendTaxiRequest().then(
            response => response.json(),
            reason => Promise.reject(reason)
        ).then(
            status => console.log(status),
            reason => console.log(reason)
        );
    }
    render() {
        
        return (
            <div>
                <h1>{this.state.approvalStatus}</h1>
            </div>
        )
    }
}
