import 'react';
import 'react-dom';

//Third party packages
import 'jquery';
import 'popper.js';
import 'bootstrap/dist/js/bootstrap';
import 'bootswatch/dist/united/bootstrap.min.css';