const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);

const port = process.env.PORT || 9090;

io.on("connection", socket => {
    console.log("Socket Connection Successful!" + socket.id)
    const routes = require("./routes/app-router")(io);
    app.use("/api", routes);
});

http.listen(port, () => {
    console.log(`Listening on port ${port}`);
});