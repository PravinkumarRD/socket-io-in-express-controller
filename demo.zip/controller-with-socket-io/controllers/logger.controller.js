exports.logInformation = io => {
    return (req, res, next) => {
        //Write logic of your controller!
        io.emit("taxiRequestApproval", "Your Taxi request has been approved!!!");
        res.send("Response Sent!!!");
    }
}