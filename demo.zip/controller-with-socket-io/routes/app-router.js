const express = require("express");

const loggerController = require("../controllers/logger.controller");
const router = express.Router();

module.exports = io => {
    router.route("/taxi-request").get(
        loggerController.logInformation(io)
    );
    return router;
}